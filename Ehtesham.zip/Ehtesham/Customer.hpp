#ifndef _CUSTOMER_
#define _CUSTOMER_

#include<iostream>
#include<string>
#include<vector>
#include "Order.hpp"

class Customer{
    private:
        std::string id;
        std::string name;
        int wallet;
        std::vector< Order* > prev_orders;
    
    public:
        Customer(int _id, std::string _name);
};

#endif