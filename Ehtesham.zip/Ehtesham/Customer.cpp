#include<iostream>
#include<string>
#include<vector>
#include "Customer.hpp"

using namespace std;

Customer::Customer(int _id, string _name){
    id = to_string(_id);
    name = _name;
    wallet = 0;
}