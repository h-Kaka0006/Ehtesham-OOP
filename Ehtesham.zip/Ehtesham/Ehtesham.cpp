#include<iostream>
#include<string>
#include<vector>
#include "Ehtesham.hpp"

using namespace std;

void Ehtesham::add_customer(string name){
    Customer* new_customer = new Customer(id++, name);
    customers.push_back(new_customer);
}