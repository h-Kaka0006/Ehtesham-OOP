#ifndef _FOOD_ITEM_
#define _FOOD_ITEM_

#include<iostream>
#include<string>

class FoodItem{
    private:
        Food food;
        int amount;
};

class Food{
    private:
        int price;
        std::string info;
    
    public:

};

#endif